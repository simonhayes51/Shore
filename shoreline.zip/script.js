document.addEventListener('DOMContentLoaded', () => {
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isSmallScreen = window.matchMedia('(max-width: 768px)').matches;

  if (!prefersReducedMotion && !isSmallScreen) {
    const parallaxElements = document.querySelectorAll('.parallax-block, .parallax-bg');
    
    const onScroll = () => {
      const scrollY = window.scrollY;
      const viewportHeight = window.innerHeight;

      parallaxElements.forEach(el => {
        const rect = el.getBoundingClientRect();
        const elTop = rect.top + scrollY;
        const elHeight = rect.height;
        
        // Calculate offset
        const factor = el.classList.contains('parallax-bg') ? -0.1 : (parseFloat(el.dataset.parallax) || 0.05);
        const offset = (scrollY + viewportHeight / 2 - (elTop + elHeight / 2)) * factor;
        
        if (el.classList.contains('parallax-bg')) {
            el.style.backgroundPositionY = `calc(50% + ${offset}px)`;
        } else {
            el.style.transform = `translateY(${offset}px)`;
        }
      });
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  // Custom Cursor Movement
  const cursor = document.querySelector('.custom-cursor');
  if (cursor && !isSmallScreen) {
    document.addEventListener('mousemove', (e) => {
      cursor.style.left = e.clientX + 'px';
      cursor.style.top = e.clientY + 'px';
    });

    // Add scale effect on clickable elements
    const clickables = document.querySelectorAll('a, button, .pill');
    clickables.forEach(el => {
      el.addEventListener('mouseenter', () => {
        cursor.style.transform = 'translate(-50%, -50%) scale(1.8) rotate(20deg)';
      });
      el.addEventListener('mouseleave', () => {
        cursor.style.transform = 'translate(-50%, -50%) scale(1) rotate(0deg)';
      });
    });
  }

  // Mobile menu or smooth scroll logic could go here if needed
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });
});
